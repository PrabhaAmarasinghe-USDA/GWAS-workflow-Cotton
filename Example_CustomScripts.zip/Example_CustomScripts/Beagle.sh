module load java
module load beagle-geno
java -Xmx900g -jar /software/7/apps/beagle-geno/5.0/beagle.16May19.351.jar gt="Input.vcf" out="Output.beagle.vcf"
