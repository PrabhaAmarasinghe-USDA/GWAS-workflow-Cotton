########################################################################################
#Linkage Disequilibrium (LD) heatmap plot generation
########################################################################################
#Import packages to R environment
library(devtools)
library(snpStats)
library(LDheatmap)
library(GAPIT)
library(ggplot2)

#Import data set
gdat<-read.csv ("A07.csv", header=TRUE)

#Subset data & extract only chrm
gdat1<-subset(gdat,chrom=='A07')

# Change SNP position as needed
center_pos <- 113633613   

# Define window
start <- center_pos - 50000
end   <- center_pos + 50000

# Subset gdat1 by position (This ensures GAPIT sees only the window)
gdat_win <- gdat1[gdat1$pos >= start & gdat1$pos <= end, ]

#Convert hapmap data into numeric data. 
datN <- GAPIT(G = gdat_win, output.numerical = TRUE)
Numericdata <- datN$GD[,-1]
Geno <- as.matrix(Numericdata)
Map0 <- datN$GM

# Subset Map0 to the same window
Map0 <- Map0[Map0$Position >= start & Map0$Position <= end, ]

Geno <- Geno[, Map0$SNP]

Gdat <- as(Geno, "SnpMatrix")

Gdis <- Map0$Position

#Find start and end positions of physical distance for annotation
min(Gdis)
max(Gdis)
ld_start <- min(Gdis)
ld_end   <- max(Gdis)

write.csv(
  data.frame(snp_id = "SA0313633613",
             ld_start = ld_start,
             ld_end = ld_end),
  "LD_block_coordinates.csv",
  row.names = FALSE
)

#Plot
png("LDPlot.png", width = 12, height = 6, units = "in", res = 300)
LDheatmap(MyHeatmap, SNP.name = c("SA07_113633613"),
          newpage = FALSE, color = heat.colors(15))
dev.off()

