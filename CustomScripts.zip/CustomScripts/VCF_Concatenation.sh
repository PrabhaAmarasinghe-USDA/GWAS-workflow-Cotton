#!/bin/bash

# Define the directory containing the VCF files
VCF_DIR="/vcf_output"
OUTPUT_VCF="combined.vcf.gz"

# Step 1: Compress each VCF file
for vcf_file in "$VCF_DIR"/*.vcf; do
    echo "Compressing $vcf_file..."
    bgzip "$vcf_file"
done

# Step 2: Index each compressed VCF file
for vcf_file in "$VCF_DIR"/*.vcf.gz; do
    echo "Indexing $vcf_file..."
    tabix -p vcf "$vcf_file"
done

# Step 3: Concatenate the compressed VCF files
echo "Concatenating VCF files..."
bcftools concat -O z -o "$OUTPUT_VCF" "$VCF_DIR"/*.vcf.gz

# Step 4: Index the concatenated VCF file
echo "Indexing the concatenated VCF file..."
tabix -p vcf "$OUTPUT_VCF"

echo "Process completed. The combined VCF file is $OUTPUT_VCF."
