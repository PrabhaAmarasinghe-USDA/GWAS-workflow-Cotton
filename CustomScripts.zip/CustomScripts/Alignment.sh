#!/bin/bash

# Define the reference genome
REF_FA=/path_to_ref_genome/Ghirsutum_578_v3.0.fa

# Define the directory containing the RIL folders
READS_DIR=/path_to_RILs/03.Rawdata

# Define the output directory for the BAM files
RESULTS_DIR=/path_to_Output/trailbams

# Create the output directory if it doesn't exist
mkdir -p "$RESULTS_DIR"


#bwa-mem2 index '/path_to_ref_genome/Ghirsutum_578_v3.0.fa' 

# Run bwa-mem2 for alignment and pipe to samtools for sorting-Loop through each directory in the reads directory
for dir in "$READS_DIR"/*; do
  if [ -d "$dir" ]; then
    dir_name=$(basename "$dir")
    
    # Loop through each R1 file in the directory
    for file in "$dir"/*_R1_*.fastq.gz; do
      if [ -f "$file" ]; then  # Check if the file exists
        file2="${file/_R1_/_R2_}"  # Replace R1 with R2 in the filename
        sample_name=$(basename "$file" _R1_001.fastq.gz)  # Adjust based on your naming convention
        
        # Check if the corresponding R2 file exists
        if [ -f "$file2" ]; then
          # Run bwa-mem2 and pipe to samtools
          bwa-mem2 mem -t 16 -R "@RG\tID:$dir_name\tPL:ILLUMINA\tSM:$sample_name" "$REF_FA" "$file" "$file2" | samtools sort -o "$RESULTS_DIR/${dir_name}.sorted.bam" -
          samtools index "$RESULTS_DIR/${dir_name}.sorted.bam"
        else
          echo "Warning: Corresponding R2 file not found for $file2"
        fi
      else
        echo "Warning: R1 file not found: $file"
      fi
    done
  fi
done
