#!/bin/bash

#conda install bioconda::bcftools
# Create a list of BAM files in the current directory
ls *.bam > bam_list.txt

# Define the reference genome
REFERENCE_GENOME="/Path_to_ref_genome/Ghirsutum_578_v3.0.fa"

# Generate a list of regions (A01 to A13 and D01 to D13)
for CHROMOSOME in {A..D}; do
  for NUM in $(seq -w 1 13); do
    REGION="${CHROMOSOME}${NUM}"
    
    # Run bcftools mpileup and bcftools call for the current region
    bcftools mpileup -b bam_list.txt -f "$REFERENCE_GENOME" -r "$REGION" | \
    bcftools call -mv -Ov -o "outputmar_${REGION}.vcf"
  done
done
