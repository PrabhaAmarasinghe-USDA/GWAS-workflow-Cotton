#################################################################################################################################################################
#CMplot package for GWAS visualization
#Package: https://github.com/YinLiLin/CMplot
#################################################################################################################################################################
#Call library
library(CMplot)

#Load processed data file:
data <- read.csv("GAPIT.Association.GWAS_Results.MLM.SCN_processed.csv", header = TRUE)

# Desired thresholds in -log10(p) scale
threshold_log <- c(6.17, 7.47)

# Convert to p-values for CMplot
threshold_p <- 10^(-threshold_log)

# Run CMplot with custom thresholds
CMplot(data,
       plot.type = "m",
       #chr.den.col=c("darkgreen", "yellow", "red"), 
       col = c("gray60", "orange", "green4", "purple2"),
       threshold = threshold_p,      
       threshold.col = c("red", "black"), 
       threshold.lty = c(1,2),      
       threshold.lwd = 2, 
       chr.labels.angle=45,
       #amplify = TRUE,  
       #signal.cex = 1.2, 
       #signal.pch = 19,  
       file = "pdf",
       file.output = TRUE,
       dpi = 300)

#QQ-plot
CMplot(data,
       plot.type="q",
       box=FALSE,
       #col=c("purple4"), 
       file="jpg",
       dpi=300,
       conf.int=TRUE,
       conf.int.col=NULL,
       threshold.col="red",
       threshold.lty=2,
       #file.output=TRUE,
       #verbose=TRUE,
       width=5,height=5)
