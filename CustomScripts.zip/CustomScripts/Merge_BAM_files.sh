#!/bin/bash

# Define the reference genome
REF_FA=/Path_to_Ref/Ghirsutum_578_v3.0.fa

# Define the directory containing the RIL folders
READS_DIR=/Path_to_RILs

# Define the output directory for the BAM files
RESULTS_DIR=/outputbams

# Create the output directory if it doesn't exist
mkdir -p "$RESULTS_DIR"

# Declare an associative array to hold BAM files for each sample
declare -A sample_bams

for dir in "$READS_DIR"/*; do
  if [ -d "$dir" ]; then
    dir_name=$(basename "$dir")
    
    # Loop through each R1 file in the directory
    for file in "$dir"/*_1.fq.gz; do
      if [ -f "$file" ]; then  # Check if the file exists
        file2="${file/_1/_2}"  # Replace _1 with _2 in the filename
        sample_name=$(basename "$file" _1.fq.gz)  # Adjust based on your naming convention
        
        # Check if the corresponding R2 file exists
        if [ -f "$file2" ]; then
          # Run bwa-mem2 and pipe to samtools
          bam_file="$RESULTS_DIR/${dir_name}_${sample_name}.sorted.bam"
          bwa-mem2 mem -t 16 -R "@RG\tID:$dir_name\tPL:ILLUMINA\tSM:$sample_name" "$REF_FA" "$file" "$file2" | samtools sort -o "$bam_file" -
          samtools index "$bam_file"
          
          # Add the BAM file to the associative array for merging
          sample_bams["$sample_name"]+="$bam_file "
        else
          echo "Warning: Corresponding R2 file not found for $file2"
        fi
      else
        echo "Warning: R1 file not found: $file"
      fi
    done
  fi
done

# Merge BAM files for each sample
for sample in "${!sample_bams[@]}"; do
  bam_files=${sample_bams[$sample]}
  merged_bam="$RESULTS_DIR/${sample}.merged.bam"
  
  # Merge the BAM files
  samtools merge -f "$merged_bam" $bam_files
  
  # Index the merged BAM file
  samtools index "$merged_bam"
done