#Script to generate a heatmap of gene expression across tissues
# Customized to visualize transcript data from ccNET
#References:
#https://github.com/raivokolde/pheatmap
#https://biostatsquid.com/step-by-step-heatmap-tutorial-with-pheatmap/
###############################################################################
#Load the packages
library(pheatmap)
library(RColorBrewer)
library(tidyverse)
library(dplyr)
library(tibble)

# Load expression data
expression_data <- read.csv("Expression_Data.csv", row.names = 1)

# Transpose, so samples are rows
expr_t <- t(expression_data)

sample_labels <- gsub("_[0-9]+$", "", rownames(expr_t))

expr_t_df <- as.data.frame(expr_t)
expr_t_df$tissue_time <- sample_labels

#Aggregate by Mean Across Replicates
expr_avg <- expr_t_df %>%
  group_by(tissue_time) %>%
  summarise(across(where(is.numeric), mean)) %>%
  column_to_rownames("tissue_time")

# Transpose back to genes as rows
expr_matrix_avg <- t(as.matrix(expr_avg))


#Log-Transform
expr_matrix_log <- log2(expr_matrix_avg + 1)
colnames(expr_matrix_log)

#Match desired Order of tissues
grep("Ovule|Fiber", colnames(expr_matrix_log), value = TRUE)
desired_order <- c("Ovule_.3DPA", "Ovule_.1DPA", "Ovule_0DPA", "Ovule_1DPA", "Ovule_3DPA", "Ovule_5DPA", "Ovule_10DPA", "Ovule_20DPA", "Ovule_25DPA", "Ovule_35DPA", "Fiber_5DPA", "Fiber_10DPA", "Fiber_20DPA", "Fiber_25DPA")
expr_matrix_ordered <- expr_matrix_log[, desired_order]

# Plot heatmap
heat_plot <-pheatmap(expr_matrix_ordered,
            cluster_rows = FALSE,
            cluster_cols = FALSE,
            clustering_distance_rows = 'euclidean',
            #clustering_distance_cols = 'euclidean',
            clustering_method = 'ward.D',
            color = colorRampPalette(c("navy", "lightyellow", "firebrick3"))(50),
            main = "Ovule Gene Expression Over Time (DPA)",
            fontsize_row = 10,
            fontsize_col = 10,
            border_color = "gray")

## Save to PDF (Give path here)
pdf(paste0("/Users/Path_to_directory", "heatmap.pdf"), height = 10, width = 8)
heat_plot
dev.off()